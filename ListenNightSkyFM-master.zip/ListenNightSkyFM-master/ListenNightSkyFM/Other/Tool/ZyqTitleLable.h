//
//  ZyqTitleLable.h
//  FMMusic
//
//  Created by zyq on 16/1/12.
//  Copyright © 2017年 lujh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZyqTitleLable : UILabel	
-(instancetype)initWithFrame:(CGRect)frame WithTitle:(NSString *)title WithColor:(UIColor *)color;
@end
