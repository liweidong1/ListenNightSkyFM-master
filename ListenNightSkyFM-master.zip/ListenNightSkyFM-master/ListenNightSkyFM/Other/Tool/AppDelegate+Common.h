//
//  AppDelegate+Common.h
//  FMMusic
//
//  Created by zyq on 16/1/13.
//  Copyright © 2017年 lujh. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate (Common)

- (void)pushNextController :(id)Controller;

@end
