//
//  ZyqLable.h
//  FMMusic
//
//  Created by zyq on 16/1/4.
//  Copyright © 2017年 lujh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZyqLable : UILabel

- (instancetype)initWithFrame:(CGRect)frame WithTitle:(NSString *)title WithImageName:(NSString * )nameString;
@end
