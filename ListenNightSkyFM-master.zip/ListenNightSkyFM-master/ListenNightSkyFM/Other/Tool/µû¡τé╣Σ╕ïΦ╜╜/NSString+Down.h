//
//  NSString+Down.h
//  FMMusic
//
//  Created by zyq on 16/1/19.
//  Copyright © 2017年 lujh. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Down)

@end

@interface NSString (MD5)
- (NSString *) MD5Hash;

@end
