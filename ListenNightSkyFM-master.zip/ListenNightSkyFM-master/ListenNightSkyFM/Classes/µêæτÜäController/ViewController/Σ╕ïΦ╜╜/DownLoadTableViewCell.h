//
//  DownLoadTableViewCell.h
//  FMMusic
//
//  Created by zyq on 16/1/20.
//  Copyright © 2017年 lujh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HomeModel.h"
@interface DownLoadTableViewCell : UITableViewCell


@property (nonatomic, strong) HotFmModel * model;
@end
