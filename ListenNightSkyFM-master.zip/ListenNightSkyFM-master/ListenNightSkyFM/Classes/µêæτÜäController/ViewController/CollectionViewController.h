//
//  CollectionViewController.h
//  FMMusic
//
//  Created by zyq on 16/1/18.
//  Copyright © 2017年 lujh. All rights reserved.
//

#import "BaseViewController.h"

@interface CollectionViewController : BaseViewController

@end
