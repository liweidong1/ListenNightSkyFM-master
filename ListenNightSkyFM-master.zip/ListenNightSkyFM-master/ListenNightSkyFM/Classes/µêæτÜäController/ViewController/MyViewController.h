//
//  MyViewController.h
//  SeeTheWorld
//
//  Created by zyq on 16/1/2.
//  Copyright © 2017年 lujh. All rights reserved.
//

#import "BaseViewController.h"

@interface MyViewController : BaseViewController

@end
