//
//  SocialModel.m
//  FMMusic
//
//  Created by zyq on 16/1/15.
//  Copyright © 2017年 lujh. All rights reserved.
//

#import "SocialModel.h"

@implementation SocialDataModel

+(BOOL)propertyIsOptional:(NSString *)propertyName {

    return YES;
}

@end
@implementation SocialModel

+(BOOL)propertyIsOptional:(NSString *)propertyName {
    return YES;
}
@end
