//
//  ContentOneModel.m
//  FMMusic
//
//  Created by zyq on 16/1/16.
//  Copyright © 2017年 lujh. All rights reserved.
//

#import "ContentOneModel.h"

@implementation ContentOneModel


+(BOOL)propertyIsOptional:(NSString *)propertyName {

    return YES;
}
@end
