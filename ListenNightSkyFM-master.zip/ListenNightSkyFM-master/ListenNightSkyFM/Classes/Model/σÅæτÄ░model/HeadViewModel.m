//
//  HeadViewModel.m
//  FMMusic
//
//  Created by zyq on 16/1/11.
//  Copyright © 2017年 lujh. All rights reserved.
//

#import "HeadViewModel.h"

@implementation HeadDataModel

+(BOOL)propertyIsOptional:(NSString *)propertyName {
    return YES;
}

@end
@implementation HeadViewModel
+(BOOL)propertyIsOptional:(NSString *)propertyName {
    return YES;
}

@end
