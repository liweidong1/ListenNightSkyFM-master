//
//  MoodDetaiModel.m
//  FMMusic
//
//  Created by zyq on 16/1/12.
//  Copyright © 2017年 lujh. All rights reserved.
//

#import "MoodDetaiModel.h"

@implementation MoodDetaiModel
+(BOOL)propertyIsOptional:(NSString *)propertyName {

    return YES;
}
@end
