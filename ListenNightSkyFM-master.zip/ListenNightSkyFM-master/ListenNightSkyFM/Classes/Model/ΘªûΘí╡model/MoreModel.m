//
//  MoreModel.m
//  FMMusic
//
//  Created by zyq on 16/1/5.
//  Copyright © 2017年 lujh. All rights reserved.
//

#import "MoreModel.h"


@implementation MoreUserModel

+(BOOL)propertyIsOptional:(NSString *)propertyName {
    return YES;
}

@end
@implementation MoreDiantaiModel


+(BOOL)propertyIsOptional:(NSString *)propertyName {

    return YES;
}

@end
@implementation MoreDataModel

+(BOOL)propertyIsOptional:(NSString *)propertyName {

    return YES;
}

@end
@implementation MoreModel


+(BOOL)propertyIsOptional:(NSString *)propertyName {
    return YES;
}
@end
