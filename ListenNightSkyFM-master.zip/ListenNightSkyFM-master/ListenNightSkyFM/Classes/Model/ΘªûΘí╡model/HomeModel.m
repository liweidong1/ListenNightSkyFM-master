//
//  HomeModel.m
//  FMMusic
//
//  Created by lujh on 17/4/3.
//  Copyright © 2017年 lujh. All rights reserved.
//

#import "HomeModel.h"



@implementation NewFmUser

+(BOOL)propertyIsOptional:(NSString *)propertyName {

    return YES;
}

@end
@implementation NewFmDitanTaiModel

+(BOOL)propertyIsOptional:(NSString *)propertyName{
    return YES;
}

@end
@implementation NewFm

+(BOOL)propertyIsOptional:(NSString *)propertyName {

    return YES;
}
@end
@implementation UserModel

+(BOOL)propertyIsOptional:(NSString *)propertyName {
    return YES;
}

@end
@implementation DianTaiModel

+(BOOL)propertyIsOptional:(NSString *)propertyName {
    return YES;
}

@end
@implementation HotFmModel
+(BOOL)propertyIsOptional:(NSString *)propertyName {
    return YES;
}

@end
@implementation CateGoryModel

+(BOOL)propertyIsOptional:(NSString *)propertyName {
    return YES;
}

@end
@implementation TuiJianModel

+(BOOL)propertyIsOptional:(NSString *)propertyName {
    return YES;
}

@end
@implementation DataModel

+(BOOL)propertyIsOptional:(NSString *)propertyName {
    return YES;
}

@end
@implementation HomeModel
+(BOOL)propertyIsOptional:(NSString *)propertyName {
    return YES;
}
@end
