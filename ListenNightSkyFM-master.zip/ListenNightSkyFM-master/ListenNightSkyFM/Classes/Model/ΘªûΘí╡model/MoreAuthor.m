//
//  MoreAuthor.m
//  FMMusic
//
//  Created by zyq on 16/1/5.
//  Copyright © 2017年 lujh. All rights reserved.
//

#import "MoreAuthor.h"



@implementation MoreAuthorDataModel

+(BOOL)propertyIsOptional:(NSString *)propertyName {
    return YES;
}

@end
@implementation MoreAuthor
+(BOOL)propertyIsOptional:(NSString *)propertyName {
    return YES;
}
@end
