//
//  NewAuthorModel.m
//  FMMusic
//
//  Created by zyq on 16/1/6.
//  Copyright © 2017年 lujh. All rights reserved.
//

#import "NewAuthorModel.h"

@implementation NewAuthorModel


@end
