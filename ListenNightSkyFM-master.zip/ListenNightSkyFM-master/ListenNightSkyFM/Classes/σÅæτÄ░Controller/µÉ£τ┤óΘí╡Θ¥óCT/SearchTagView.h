//
//  SearchTagView.h
//  FMMusic
//
//  Created by zyq on 16/1/14.
//  Copyright © 2017年 lujh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchTagView : UIView

@property (nonatomic, strong)NSMutableArray * dataArray;

@end
