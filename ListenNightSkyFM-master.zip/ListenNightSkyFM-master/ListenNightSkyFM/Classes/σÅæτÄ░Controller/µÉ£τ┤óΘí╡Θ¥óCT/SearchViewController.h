//
//  SearchViewController.h
//  FMMusic
//
//  Created by zyq on 16/1/14.
//  Copyright © 2017年 lujh. All rights reserved.
//

#import "BaseViewController.h"

@interface SearchViewController : BaseViewController

@end
