//
//  HotSearchViewController.h
//  FMMusic
//
//  Created by zyq on 16/1/15.
//  Copyright © 2017年 lujh. All rights reserved.
//

#import "MoreViewController.h"

@interface HotSearchViewController : MoreViewController

@end
