//
//  MoodDetailViewController.h
//  FMMusic
//
//  Created by zyq on 16/1/12.
//  Copyright © 2017年 lujh. All rights reserved.
//

#import "MoreFmViewController.h"

@interface MoodDetailViewController : MoreFmViewController

@end
