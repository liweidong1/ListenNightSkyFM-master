//
//  MainPostTableViewCell.h
//  FMMusic
//
//  Created by zyq on 16/1/16.
//  Copyright © 2017年 lujh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ContentFrameModel.h"
@interface MainPostTableViewCell : UITableViewCell

@property (nonatomic, strong) ContentFrameModel * frameModel;
@end
