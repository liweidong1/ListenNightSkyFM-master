//
//  ContentModel.m
//  FMMusic
//
//  Created by zyq on 16/1/10.
//  Copyright © 2017年 lujh. All rights reserved.
//

#import "ContentModel.h"

@implementation ContentDataModel

+(BOOL)propertyIsOptional:(NSString *)propertyName {
    return YES;
}

@end
@implementation ContentModel
+(BOOL)propertyIsOptional:(NSString *)propertyName {
    return YES;
}
@end
