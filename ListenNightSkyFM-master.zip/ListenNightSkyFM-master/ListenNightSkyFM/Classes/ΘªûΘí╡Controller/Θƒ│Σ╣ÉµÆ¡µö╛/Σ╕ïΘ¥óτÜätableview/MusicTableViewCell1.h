//
//  MusicTableViewCell.h
//  FMMusic
//
//  Created by zyq on 16/1/10.
//  Copyright © 2017年 lujh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ContentModel.h"
#import "ContentFrame.h"
@interface MusicTableViewCell1 : UITableViewCell

@property (nonatomic, strong) ContentDataModel * dataModel;
//
@property (nonatomic, strong)  ContentFrame * viewFrame;
@end
