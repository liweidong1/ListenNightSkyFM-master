//
//  MusicTableViewCell.h
//  FMMusic
//
//  Created by zyq on 16/1/10.
//  Copyright © 2017年 lujh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MusicTableViewCell : UITableViewCell
@property (nonatomic, copy) NSString * picUrl;
@property (nonatomic, copy) NSString * favnum;
@property (nonatomic, copy) NSString * viewnum;
@property (nonatomic, copy) NSString * content;
@end
