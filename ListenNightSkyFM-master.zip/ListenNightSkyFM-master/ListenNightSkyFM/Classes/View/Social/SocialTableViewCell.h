//
//  SocialTableViewCell.h
//  FMMusic
//
//  Created by zyq on 16/1/15.
//  Copyright © 2017年 lujh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SocialFrameModel.h"
@interface SocialTableViewCell : UITableViewCell

@property (nonatomic, strong)SocialFrameModel * frameModel;
@end
