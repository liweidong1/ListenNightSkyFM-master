//
//  HotFMAuthorDetailTableViewCell.h
//  FMMusic
//
//  Created by zyq on 16/1/6.
//  Copyright © 2017年 lujh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HomeModel.h"
@interface HotFMAuthorDetailTableViewCell : UITableViewCell


@property (nonatomic, strong)DianTaiModel * model;
@end
