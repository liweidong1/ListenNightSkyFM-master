//
//  MoreTableViewCell.h
//  FMMusic
//
//  Created by zyq on 16/1/5.
//  Copyright © 2017年 lujh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MoreModel.h"
@interface MoreTableViewCell : UITableViewCell

@property (nonatomic, strong) HotFmModel * moreModel;
@end
