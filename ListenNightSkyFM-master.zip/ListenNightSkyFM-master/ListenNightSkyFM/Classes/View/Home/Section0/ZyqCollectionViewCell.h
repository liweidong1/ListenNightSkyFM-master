//
//  ZyqCollectionViewCell.h
//  FMMusic
//
//  Created by zyq on 16/1/4.
//  Copyright © 2017年 lujh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HomeModel.h"
@interface ZyqCollectionViewCell : UICollectionViewCell

@property (nonatomic, strong) CateGoryModel * model;

@end
