//
//  PromotionCollectionViewCell.h
//  FMMusic
//
//  Created by 卢家浩 on 2017/7/16.
//  Copyright © 2017年 zyq. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HomeModel.h"
@interface PromotionCollectionViewCell : UICollectionViewCell
@property (nonatomic, strong) DianTaiModel * model;
@end
