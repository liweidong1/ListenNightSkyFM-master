//
//  FindSection2Cell.h
//  FMMusic
//
//  Created by zyq on 16/1/13.
//  Copyright © 2017年 lujh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FindMoreAuthorModel.h"
@interface FindSection2Cell : UICollectionViewCell

@property (nonatomic, strong) DianTaiModel * model;

@end
