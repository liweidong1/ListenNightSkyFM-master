//
//  SectionsCollectionViewCell.h
//  FMMusic
//
//  Created by zyq on 16/1/12.
//  Copyright © 2017年 lujh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SectionsCollectionViewCell : UICollectionViewCell

- (void)updateViewWith:(NSString *)title WithImageName:(NSString * )name;
@end
